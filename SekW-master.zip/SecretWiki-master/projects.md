---
title: Secret Projects
---

# Secret Community Projects

A list of all active community projects or contribution available for use or consumption through Open Source standards.

### PANIC Monitor your Validator on the Secret Network

This allows node operators to monitor their setups, with an active bot that you can connect to a telegram, email or phone call through twilio!!

[Github](https://github.com/mohammedpatla/panic_cosmos)

Contributed by : Mohammed Patla | SecureSecrets.network


### Secret Network API

This is a Rest API provided by ChainofSecrets.org for the Secret Network

[API](https://api.chainofsecrets.org/#/)

Contributed by : ChainofSecrets.org
