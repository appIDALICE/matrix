# This directory contains optional components: 

Note: None of these are loaded into the path or loaded by configurations

* Contrib 
* Alts
* Opt configurations for 3rd party tools
* Additional color layouts
* etc.
