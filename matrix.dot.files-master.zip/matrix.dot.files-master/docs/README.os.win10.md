# Windows 10

Support information for Windows 10.

## Non-WSL Implementations

Use terminal to install cygwin and gnutools

## WSL 2

Install the Ubuntu WSL2 implementation.