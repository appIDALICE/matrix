import { Address, PubkeyBundle } from "@iov/bcp";
export declare function pubkeyToAddress(pubkey: PubkeyBundle, prefix: string): Address;
