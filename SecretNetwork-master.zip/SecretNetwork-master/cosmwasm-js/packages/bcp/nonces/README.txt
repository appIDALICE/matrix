Directory used to trigger lerna package updates for all packages
