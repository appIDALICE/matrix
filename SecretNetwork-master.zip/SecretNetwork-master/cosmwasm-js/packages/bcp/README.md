# @cosmwasm/bcp

[![npm version](https://img.shields.io/npm/v/@cosmwasm/bcp.svg)](https://www.npmjs.com/package/@cosmwasm/bcp)

A [BCP](https://github.com/iov-one/iov-core/tree/master/packages/iov-bcp) implementation for CosmWasm.

## License

This package is part of the cosmwasm-js repository, licensed under the Apache
License 2.0 (see
[NOTICE](https://github.com/confio/cosmwasm-js/blob/master/NOTICE) and
[LICENSE](https://github.com/confio/cosmwasm-js/blob/master/LICENSE)).
