import { StdTx } from "./types";
export declare function unmarshalTx(data: Uint8Array): StdTx;
