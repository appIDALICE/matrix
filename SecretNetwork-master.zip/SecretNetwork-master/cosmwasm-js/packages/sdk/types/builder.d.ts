export declare function isValidBuilder(builder: string): boolean;
