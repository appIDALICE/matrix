(async () => {
  const x = require("./packages/sdk/src/index.ts");
  console.log(x);
})();
