Just `make`. :rainbow:
