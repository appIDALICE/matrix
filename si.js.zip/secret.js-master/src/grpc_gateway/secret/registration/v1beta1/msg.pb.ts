/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type RaAuthenticate = {
  sender?: Uint8Array
  certificate?: Uint8Array
}

export type MasterCertificate = {
  bytes?: Uint8Array
}

export type Key = {
  key?: Uint8Array
}