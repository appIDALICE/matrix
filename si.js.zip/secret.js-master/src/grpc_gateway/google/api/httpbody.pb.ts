/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as GoogleProtobufAny from "../protobuf/any.pb"
export type HttpBody = {
  content_type?: string
  data?: Uint8Array
  extensions?: GoogleProtobufAny.Any[]
}