/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type Metadata = {
  version?: string
  controller_connection_id?: string
  host_connection_id?: string
  address?: string
  encoding?: string
  tx_type?: string
}