/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as CosmosAuthV1beta1Auth from "../../../../cosmos/auth/v1beta1/auth.pb"
export type InterchainAccount = {
  base_account?: CosmosAuthV1beta1Auth.BaseAccount
  account_owner?: string
}