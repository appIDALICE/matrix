/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type DenomTrace = {
  path?: string
  base_denom?: string
}

export type Params = {
  send_enabled?: boolean
  receive_enabled?: boolean
}