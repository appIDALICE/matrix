/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as IbcCoreClientV1Client from "../../../core/client/v1/client.pb"
export type ClientState = {
  chain_id?: string
  height?: IbcCoreClientV1Client.Height
}