/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type PubKey = {
  key?: Uint8Array
}

export type PrivKey = {
  secret?: Uint8Array
}