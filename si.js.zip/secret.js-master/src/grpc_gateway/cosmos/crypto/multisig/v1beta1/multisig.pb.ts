/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type MultiSignature = {
  signatures?: Uint8Array[]
}

export type CompactBitArray = {
  extra_bits_stored?: number
  elems?: Uint8Array
}