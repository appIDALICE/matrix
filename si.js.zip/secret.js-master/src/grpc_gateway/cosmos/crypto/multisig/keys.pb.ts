/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as GoogleProtobufAny from "../../../google/protobuf/any.pb"
export type LegacyAminoPubKey = {
  threshold?: number
  public_keys?: GoogleProtobufAny.Any[]
}