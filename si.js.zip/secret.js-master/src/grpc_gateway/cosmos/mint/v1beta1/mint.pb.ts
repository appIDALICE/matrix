/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type Minter = {
  inflation?: string
  annual_provisions?: string
}

export type Params = {
  mint_denom?: string
  inflation_rate_change?: string
  inflation_max?: string
  inflation_min?: string
  goal_bonded?: string
  blocks_per_year?: string
}