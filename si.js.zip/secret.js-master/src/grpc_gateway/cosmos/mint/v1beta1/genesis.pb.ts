/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as CosmosMintV1beta1Mint from "./mint.pb"
export type GenesisState = {
  minter?: CosmosMintV1beta1Mint.Minter
  params?: CosmosMintV1beta1Mint.Params
}