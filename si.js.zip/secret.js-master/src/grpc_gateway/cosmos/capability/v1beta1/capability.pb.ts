/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type Capability = {
  index?: string
}

export type Owner = {
  module?: string
  name?: string
}

export type CapabilityOwners = {
  owners?: Owner[]
}