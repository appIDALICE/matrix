/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as GoogleProtobufAny from "../../../google/protobuf/any.pb"
import * as CosmosAuthV1beta1Auth from "./auth.pb"
export type GenesisState = {
  params?: CosmosAuthV1beta1Auth.Params
  accounts?: GoogleProtobufAny.Any[]
}