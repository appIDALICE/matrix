/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type Pairs = {
  pairs?: Pair[]
}

export type Pair = {
  key?: Uint8Array
  value?: Uint8Array
}