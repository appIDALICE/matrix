/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type Coin = {
  denom?: string
  amount?: string
}

export type DecCoin = {
  denom?: string
  amount?: string
}

export type IntProto = {
  int?: string
}

export type DecProto = {
  dec?: string
}