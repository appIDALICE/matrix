/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as CosmosAuthzV1beta1Authz from "./authz.pb"
export type GenesisState = {
  authorization?: CosmosAuthzV1beta1Authz.GrantAuthorization[]
}