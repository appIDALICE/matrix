/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/
export type EventGrant = {
  msg_type_url?: string
  granter?: string
  grantee?: string
}

export type EventRevoke = {
  msg_type_url?: string
  granter?: string
  grantee?: string
}