/* eslint-disable */
// @ts-nocheck
/*
* This file is a generated Typescript file for GRPC Gateway, DO NOT MODIFY
*/

import * as CosmosFeegrantV1beta1Feegrant from "./feegrant.pb"
export type GenesisState = {
  allowances?: CosmosFeegrantV1beta1Feegrant.Grant[]
}