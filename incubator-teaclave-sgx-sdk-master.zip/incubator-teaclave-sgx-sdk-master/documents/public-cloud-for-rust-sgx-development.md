---
permalink: /sgx-sdk-docs/public-cloud-for-rust-sgx-dev
---
# List of public available cloud service provide for Rust SGX development

- [Azure Confidential Computing DCsV2 Node](https://azure.microsoft.com/en-us/updates/intel-sgx-based-confidential-computing-vms-now-available-on-azure-dedicated-hosts/)
- [SecretVPS](http://www.secretvps.io/rust-sgx)

More and more SGX2 platforms are coming up in 2021!
