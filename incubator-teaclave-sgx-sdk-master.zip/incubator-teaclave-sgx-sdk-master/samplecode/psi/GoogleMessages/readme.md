```
protoc -I=.  --cpp_out=.  Messages.proto
```