#!/bin/bash -e

make
cd bin && ./app
