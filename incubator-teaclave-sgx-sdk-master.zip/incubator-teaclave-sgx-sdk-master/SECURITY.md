# Security Policy

## Reporting a Vulnerability

We take a very active stance in eliminating security problems in Teaclave. We
strongly encourage folks to report such problems to our private mailing list
first ([private@teaclave.apache.org](mailto:private@teaclave.apache.org)),
before disclosing them in a public forum.
