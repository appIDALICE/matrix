# Secret Contract Development Toolkit - Permits

⚠️ This package is a sub-package of the `secret-toolkit` package. Please see its crate page for more context.

Utils for implementing permits, used by SNIP20 & SNIP721.
